package bt;

public class QLSV {
	private SinhVien[] svArray;
	private int count;
	private int countFullName;
	// Constructors
	public QLSV() {
		svArray = new SinhVien[10];
		count = 0;
	}
	// Get
	public int getCount() {
		return count;
	}
	public int getCountFulLName() {
		return countFullName;
	}
	// Find All
	public SinhVien[] findAll() {
		return svArray;
	}
	// Resize array
	private void resize() {
		SinhVien[] newArray = new SinhVien[svArray.length * 2]; // increase array.length
        for (int i = 0; i < svArray.length; i++) {
            newArray[i] = svArray[i];
        }
        svArray = newArray;
	}
	

	// Add
	public void addSinhVien(SinhVien sinhvien) {
		if (count >= svArray.length) {
            resize(); // callback this function if array was full
        }
		svArray[count] = new SinhVien();
        svArray[count] = sinhvien;
        count++;
	}
	// Delete
	public boolean delSinhVien(String masv) {
		int target = -1;
		// find target
		for (int i = 0; i<count; i++) {
			if (svArray[i].getMasv().equals(masv)) {
				target = i;
				break;
			}
		}
		if (target == -1) {
			return false;
		} else {
		// delete target
			if (target > count -1) {
			svArray[target] = null;
			} else {
				for (int i = target; i< count-1; i++) {
					svArray[i] = svArray[i+1];
				}
			}
			count--;
			return true;
		}
	}
	// Find by masv
	public SinhVien findByMasv(String masv) {
		for (int i = 0; i<count; i++) {
			if (svArray[i].getMasv().equals(masv)) {
				return svArray[i];
			}
		}
		return null;
	}
	// Find by fullname
	public SinhVien[] findByFullName(String fullname) {
		SinhVien[] tmpf = new SinhVien[10];
		countFullName = 0;
		for (int i = 0; i<count; i++) {
			if (svArray[i].getFullname().equals(fullname)) {
				tmpf[countFullName] = svArray[i];
				countFullName++;
			}
		}
		if (countFullName == 0)
			return null;
		else {
			return tmpf;
		}
	}
	// Change
	public void changeSinhVien(SinhVien sinhvien, String masv) {
		for (int i = 0; i<count; i++) {
			if (svArray[i].getMasv().equals(masv)) {
				svArray[i] = sinhvien;	
			}
		}
	}
}
