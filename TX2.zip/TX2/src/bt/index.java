package bt;

import java.util.Scanner;

public class index {
	public static void main(String[] args) { 
		View view = new View();
		QLSV qlsv = new QLSV();
		Scanner sc = new Scanner(System.in);
		int chose;
		do {
			view.menu();
			chose = sc.nextInt();
			sc.nextLine();
			if (chose <0 || chose > 8) {
				System.out.println("Vui long nhap lai");
			} else {
				switch (chose) {
				case 1:
					int tmp1 = -1;
					do {
					System.out.println();
					view.displayAll(qlsv.findAll(), qlsv.getCount());
					System.out.println("\nNhap 0 de quay lai: ");
					tmp1 = sc.nextInt();
					} while (tmp1 != 0);
					break;
				case 2:
					System.out.print("Nhap so luong sinh vien can nhap: ");
					int n = sc.nextInt();
					for (int i = 0; i<n; i++) {
						System.out.println("SV" + (i+1));
						qlsv.addSinhVien(view.inputSV());
					}
					System.out.println("SUCCESS");
					break;
 				case 3:
 					qlsv.addSinhVien(view.inputSV());
					System.out.println("SUCCESS");
 					break;
				case 4:
					String tmp2;
					do {
						System.out.println();
						view.displayAll(qlsv.findAll(), qlsv.getCount());
						System.out.println("\n(*Nhap 0 de quay lai)");
						System.out.print("Nhap MaSV cua sinh vien can xoa: ");
						tmp2 = sc.nextLine();
						if (qlsv.delSinhVien(tmp2)) {
							System.out.println("DELETED");
							break;
						} else if (tmp2.equals("0")) {
							break;
						}else{
							System.out.println("ERROR: MaSV khong ton tai");
						}
					} while (true);
					break;
				case 5:
					String tmp5;
					do {
						System.out.println();
						view.displayAll(qlsv.findAll(), qlsv.getCount());
						System.out.println("\n(*Nhap 0 de quay lai)");
						System.out.print("Nhap MaSV cua sinh vien can sua: ");
						tmp5 = sc.nextLine();
						if (tmp5.equals("0")) {
							break;
						} else if (qlsv.findByMasv(tmp5) == null) {
							System.out.println("ERROR: MaSV khong ton tai");
						} else {
							System.out.println("!!!Hay sua thong tin!!!");
							qlsv.changeSinhVien(view.inputSV(), tmp5);
							System.out.println("CHANGED");
							break;
						} 
					} while (true);
					break;
				case 6:
					String tmp6;
					do {
						System.out.println("\n(*Nhap 0 de quay lai)");
						System.out.print("Nhap MaSV cua sinh vien can tim: ");
						tmp6 = sc.nextLine();
						if (tmp6.equals("0")) {
							break;
						} else if (qlsv.findByMasv(tmp6) == null) {
							System.out.println("ERROR: MaSV khong ton tai");
						} else {
							System.out.println(qlsv.findByMasv(tmp6).toString());
							break;
						}
					} while (true);
					break;
				case 7:
					String tmp7;
					do {
						System.out.println("\n(*Nhap 0 de quay lai)");
						System.out.print("Nhap Ho ten cua sinh vien can tim: ");
						tmp7 = sc.nextLine();
						if (tmp7.equals("0")) {
							break;
						} else if (qlsv.findByFullName(tmp7) == null) {
							System.out.println("ERROR: Ho ten khong ton tai");
						} else {
							SinhVien[] tmpsv = new SinhVien[qlsv.getCountFulLName()];
							tmpsv = qlsv.findByFullName(tmp7);
							for (int i = 0; i<qlsv.getCountFulLName(); i++) {
								System.out.println(tmpsv[i].toString());
							}
						}
					} while (true);
					break;
				case 8: 
					System.out.println("-YOUR PROGRAM HAS BEEN SHUTDOWN-");
					System.exit(0);
				}
			}
		} while (chose != 8);
		System.out.println("YOUR PROGRAM HAS BEEN SHUTDOWN");
	}

}
