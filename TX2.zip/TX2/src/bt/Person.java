package bt;

public class Person {
	private String fullname;
	private String dob;
	private String gender;
	private long cccd;
	// Constructors
	public Person(String fullname, String dob, String gender, long cccd) {
		super();
		this.fullname = fullname;
		this.dob = dob;
		this.gender = gender;
		this.cccd = cccd;
	}
	//Get and set
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getCccd() {
		return cccd;
	}
	public void setCccd(long cccd) {
		this.cccd = cccd;
	}
	@Override
	public String toString() {
		return "Ho ten: " + fullname + " Ngay sinh: " + dob + " Gioi Tinh: " + gender + " CCCD: " + cccd;
	}
}
