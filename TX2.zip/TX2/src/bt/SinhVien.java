package bt;

public class SinhVien extends Person {
	private String masv;
	private String major;
	private String username;
	private String password;
	//Constructors
	public SinhVien() {
		super("Nguyen Van A", "0-0-0", "nam", 12345678);
	}
	public SinhVien(String fullname, String dob, String gender, long cccd, String masv, String major, String username,
			String password) {
		super(fullname, dob, gender, cccd);
		this.masv = masv;
		this.major = major;
		this.username = username;
		this.password = password;
	}
	// Get and Set
	public String getMasv() {
		return masv;
	}
	public void setMasv(String masv) {
		this.masv = masv;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "Ma SV: " + masv + " Chuyen Nganh: " + major + " Tai khoan: " + username + " Mat khau: " + password
				+ " " + super.toString();
	}
}
