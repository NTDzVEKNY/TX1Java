package bt;

import java.util.Scanner;

public class View {
	Scanner sc = new Scanner(System.in);
	public void menu() {
		System.out.println("-----------MENU-----------");
		System.out.println("1. Hien thi danh sach sinh vien");
		System.out.println("2. Them nhieu sinh vien");
		System.out.println("3. Them 1 sinh vien");
		System.out.println("4. Xoa 1 sinh vien");
		System.out.println("5. Sua 1 sinh vien");
		System.out.println("6. Tim kiem sinh vien theo Ma sinh vien");
		System.out.println("7. Tim kiem sinh vien theo Ten sinh vien");
		System.out.println("8. Exit");
		System.out.println("*----------(int)----------");
		System.out.print("Your Choose: ");
	}
	public SinhVien inputSV() {
		SinhVien sv = new SinhVien();
		System.out.flush();
		System.out.print("Nhap Ma Sinh Vien: ");
		sv.setMasv(sc.nextLine());
		System.out.flush();
		System.out.print("Nhap ho va ten: ");
		sv.setFullname(sc.nextLine());
		System.out.flush();
		System.out.print("Nhap ngay sinh: ");
		sv.setDob(sc.nextLine());
		System.out.flush();
		System.out.print("Nhap gioi tinh: ");
		sv.setGender(sc.nextLine());
		System.out.flush();
		System.out.print("Nhap chuyen nganh: ");
		sv.setMajor(sc.nextLine());
		System.out.flush();
		System.out.print("Nhap tai khoan");
		sv.setUsername(sc.nextLine());
		System.out.flush();
		System.out.print("Nhap mat khau");
		sv.setPassword(sc.nextLine());
		System.out.print("Nhap CCCD (nhap so nguyen): ");
		sv.setCccd(sc.nextLong());
		sc.nextLine();
		System.out.flush();
		System.out.println("*-------------------------");
		return sv;	
	}
	// Display All
	public void displayAll(SinhVien[] sv, int count) {  
		System.out.println("----------Danh sach sinh vien----------");
		for (int i = 0; i<count; i++ ) {
			System.out.println(sv[i].toString());
		}
		System.out.println("---------------------------------------");
	}
}
